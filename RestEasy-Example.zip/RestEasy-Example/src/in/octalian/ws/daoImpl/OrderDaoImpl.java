package in.octalian.ws.daoImpl;

import in.octalian.ws.dao.OrderDao;
import in.octalian.ws.model.Order;

public class OrderDaoImpl implements OrderDao {

	@Override
	public void saveOrder(Order order) {
		// TODO Auto-generated method stub

	}

	@Override
	public Order getOrderDetails(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteOrder(int id) {
		// TODO Auto-generated method stub

	}

}
