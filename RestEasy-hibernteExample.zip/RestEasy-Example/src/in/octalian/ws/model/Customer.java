package in.octalian.ws.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cascade;

@XmlRootElement(name = "customer")
@Entity
@Table(name="custdetails")
public class Customer {
	@Id
	@Column(name="custId")
	private int id;	
	private String name;
	private double salary;
	
	
	@OneToMany(fetch=FetchType.LAZY, targetEntity=Order.class, cascade=CascadeType.ALL)
	@JoinColumn(name = "custId", referencedColumnName="custId")
	@XmlElement
	private Set<Order> order;
	

	public Customer() {
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	/*@XmlTransient
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}*/
	@XmlTransient
	public Set<Order> getOrder() {
		return order;
	}

	public void setOrder(Set<Order> order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return id + "::" + name + "::" + salary;
	}

}
